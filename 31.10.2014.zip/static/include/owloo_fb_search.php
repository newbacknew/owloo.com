<div class="owloo_tw_search">
            <div class="owloo_fb_search_submit"></div>
            <form id="owloo_fb_search_form" method="get" action="">
                <input type="text"  id="owloo_fb_search_username" placeholder="Analiza una página de Facebook, ejemplo https://facebook.com/..." name="username" />
            </form>
        </div>