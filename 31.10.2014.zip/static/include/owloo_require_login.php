<div class="owloo_hide_data_bg">
    <div class="owloo_req_login">
        <div>Inicia sesión o regístrate gratis</div>
        <div>
            <div>Regístrate gratis para acceder a esta información</div>
            <div><a href="<?=URL_ROOT_HTTPS?>userMgmt/signup.php"><button class="owloo_btn owloo_btn_orange" onclick="window.location='<?=URL_ROOT_HTTPS?>userMgmt/signup.php'">Regístrate hoy - GRATIS</button></a></div>
            <div>Ya dispones de una cuenta? <a href="<?=URL_ROOT_HTTPS?>userMgmt/login.php">inicia sesión</a>!</div>                        
        </div>
    </div>
</div>