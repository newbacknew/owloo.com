<link rel="shortcut icon" href="<?=URL_IMAGES?>favicon.ico" />
    <link rel="stylesheet" type="text/css" href="<?=URL_CSS?>style.css?v=2.11" />
    <script type="text/javascript" src="<?=URL_JS?>pace.min.js"></script>
    <?php if(get_current_page()=='twitter'){ ?><link rel="stylesheet" type="text/css" href="<?=URL_CSS?>jquery.ui.custom.min.css?v=1.10.5" /><?php } ?>
    <script type="text/javascript">
     var _gaq = _gaq || [];
     _gaq.push(['_setAccount', 'UA-18187325-45']);
     _gaq.push(['_trackPageview']);
     (function() {
       var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
       ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
       var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
     })();
    </script>