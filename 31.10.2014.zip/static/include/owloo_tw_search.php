<div class="owloo_tw_search">
            <div class="owloo_tw_search_submit"></div>
            <form id="owloo_tw_search_form" method="post" action="<?=URL_ROOT?>twitter-stats/userpageadd/">
                <input type="text" placeholder="Analiza gratis un perfil de Twitter, ejemplo @tunombre" name="txttwittername" />
            </form>
        </div>