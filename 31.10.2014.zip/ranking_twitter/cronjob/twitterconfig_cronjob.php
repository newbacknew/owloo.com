<?php
/*define("Consumer_Key", "CPj4D8nTdwv7M3odtKNAw");
define("Consumer_Secret", "XajSKKcZWQtEaOHYfSGjz6Tu19uQZFCDVluwHzyxmgI");
define("Access_Token", "113414227-o3RrPvM7iQUSieKTwfuVuq6jOiN7NL5PiDg83mk3");
define("Access_Token_Secret", "Qy1R9SkHl5O18NGi58lF3qgmbYCLxFkH5hei5ljGrA");*/

$code_app = array(); 
//$code_app = array('Consumer_Key' => '', 'Consumer_Secret' => '', 'Access_Token' => '', 'Access_Token_Secret' => '');

//@DavidDev13
$code_app[0] = array('user' => 'DavidDev13', 'Consumer_Key' => 'OLaIAjq3K77fgzViSwvw', 'Consumer_Secret' => '73giTNkPYk685LF9xnAI94bnHW0ggXrMCUv1GvNg', 'Access_Token' => '1583028896-8rak2KkxCaHK0UIPck7892xNXDxTFOVNDJ6iuMq', 'Access_Token_Secret' => '6Cr2jqrs5ebKcjfItywvEevey7Ty5CvYwm662Jr8YY');

//@jcanesse78
$code_app[1] = array('user' => 'jcanesse78', 'Consumer_Key' => '3VJ0PLVMRQmnsOQAuhqvbw', 'Consumer_Secret' => 'Xkx5PjMFYez3AjeRbOBqcpXRocXdOzGAcmr6T94Yi7M', 'Access_Token' => '1583309112-ZpANrt5JfuLgAQNhb5b8xg3Fsio1yLQJdO7Q9YD', 'Access_Token_Secret' => '5GlNeqckg8FVChPqmHNCeMnalyM16FO0FWF61WZQ');

//@jamendez567
$code_app[2] = array('user' => 'jamendez567', 'Consumer_Key' => 'O1Jm9EFa02Gab4PzDS15A', 'Consumer_Secret' => 'ADNe9arpPpOxS9mNXEoBc6kMDhavyUnRf1rL9USY', 'Access_Token' => '1583329698-ppgYU9kX4Hl1z9LIJnHVcqMPlZGS7eeDNhfaIG4', 'Access_Token_Secret' => 'PyAQcTr5ocAeWEJmaV36cW8rQHriqigoV84TtnXG1mQ');

//@latamowl
$code_app[3] = array('user' => 'latamowl', 'Consumer_Key' => 'vdBJNMze9lsaaaiUOqp82Q', 'Consumer_Secret' => 'BaXeOD4iCKNOnQiMgCyosT4eDe6S1EAty7l0JiiKZc', 'Access_Token' => '1583347998-WlPwYTdlvPwd97xbDV2mSMSdKbpRQ7qxMs0w7w7', 'Access_Token_Secret' => 'DyQcQgseBPkJnQxxK7yvXvrbyAZUbdnTH3plth3t9TY');

//@decanesse
$code_app[4] = array('user' => 'decanesse', 'Consumer_Key' => 'LWKCxtHD72tSY0NutMGjNw', 'Consumer_Secret' => 'E12eymWuf9S4XY1YiFPNMtq5iddOtrZBeZIKHcaf8', 'Access_Token' => '1583406408-0kBfec1FpMVBcAyEsAhioAMeTgkmYT26luCfZjW', 'Access_Token_Secret' => 'hxVP4huEQmcV0o6yMaC3trrE1BW761IjeiRD6mrkP4');

//@user_default
//$code_app[5] = array('user' => 'user_default', 'Consumer_Key' => 'CPj4D8nTdwv7M3odtKNAw', 'Consumer_Secret' => 'XajSKKcZWQtEaOHYfSGjz6Tu19uQZFCDVluwHzyxmgI', 'Access_Token' => '113414227-o3RrPvM7iQUSieKTwfuVuq6jOiN7NL5PiDg83mk3', 'Access_Token_Secret' => 'Qy1R9SkHl5O18NGi58lF3qgmbYCLxFkH5hei5ljGrA');

//@cccaaaaceres
$code_app[5] = array('user' => 'cccaaaaceres', 'Consumer_Key' => 'nsDh9lNOvvYV2hTpk6Nhw', 'Consumer_Secret' => 'QfhR0RJWpn0x1ZxprJ0rLbS1ElBrvW5GNgS4NDXKams', 'Access_Token' => '1623585456-tvo2HmP4d1GjBWGbppksUsuruWadllstmOTPJwg', 'Access_Token_Secret' => 'snbJ9c2OeSzEwdAAWK5JTp2mMQJN5zQn4npnmGJF0');

//@JuanaJcaaastro
$code_app[6] = array('user' => 'JuanaJcaaastro', 'Consumer_Key' => 'BcWhNxxzK0Dj6lh7ftsg', 'Consumer_Secret' => 'iW00dZRO4NmsoNU6ryOPNFUFqtfdmPLUePxguWgPI', 'Access_Token' => '1623614676-3VtjP1U6a3U5lK54pPHIDFm80KxXux3OHfmQlLj', 'Access_Token_Secret' => 'e5blSIA5rTXeWJu37GmPS731jDwvYC87bCfLbg9fGc');

//@MarcosdelCasti1
$code_app[7] = array('user' => 'MarcosdelCasti1', 'Consumer_Key' => '8XPo6roVscH7Q9dI50vQ', 'Consumer_Secret' => '7JSGJ5WzNasdE0s7qstcKZnzQq5jHRJALP87v97N4', 'Access_Token' => '1623687877-Okxh7pmIWt2u5dgyIGXdPKOEXdo6uAbsfUv9tG6', 'Access_Token_Secret' => '6by4OIMg0aRFa7GH3Na58lDf6kf8ierko6nCPOSa4c');

//@JuanArguell
$code_app[8] = array('user' => 'JuanArguell', 'Consumer_Key' => 'kYLyF44BdKuXnOdwQIktw', 'Consumer_Secret' => 'U2Z1wiowCII2mCv1CReyX94aRcpJyxEzkO2TMbgzKk', 'Access_Token' => '1623718998-dvt8ClYNuA4XgnlmKKn8eXDgNvTsAY3yzo5OwqY', 'Access_Token_Secret' => 'alXcFKzKJrlJNIWKqW3cUjNRGkvWr4bs3bWVqw3Dc');

//@jjgizmodo
$code_app[9] = array('user' => 'jjgizmodo', 'Consumer_Key' => 'sGkFaJ0SogRHPOMgUUTaVA', 'Consumer_Secret' => 'YiaDBA0dUqRZrr7L8kztXkLkOvhxEKbeZlXrrJR8g', 'Access_Token' => '1623770234-kSpKKeSpxamt2z8FqO6Ja6g1Db3Je4BljLKgBPs', 'Access_Token_Secret' => '5KQE4tW3vdBie7x4JnhUaomWKCmG2xso4f3yGDR3TM');